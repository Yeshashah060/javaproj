

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class first
 */
public class first extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public first() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String mail=request.getParameter("mail");
		String number=request.getParameter("number");
		String password=request.getParameter("password");
		String color=request.getParameter("color");
		out.print("name "+name);
		out.print("name "+mail);
		out.print("name "+number);
		out.print("name "+password);
		out.print("name "+color);
		HttpSession session=request.getSession();
		out.print("<center>");
		session.setAttribute("uname",name);
		out.print("<br>");
		session.setAttribute("umail",mail);
		out.print("<br>");
		session.setAttribute("unumber",number);
		out.print("<br>");
		session.setAttribute("upassword",password);
		out.print("<br>");
		session.setAttribute("ucolor",color);
		out.print("<br>");
		out.print("<a href='second'>  visit </a>");
		out.print("</center>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
